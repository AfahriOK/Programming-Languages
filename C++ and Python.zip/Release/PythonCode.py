import re
import string

def printMenu():
	print('1: Display a Multiplication Table')
	print('2: Double a value')
	print('3: Exit')

def doubleVal(number):
	return number * 2

def printTable(number):
	for i in range(1,11):
		print (str(number) + ' X ' + str(i) + ' = ' + str(number * i))
	return 0