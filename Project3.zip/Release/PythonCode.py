import re
import string
from collections import Counter #Used to count the items

#Reads and counts all items in the file
def readItems():
	file = open("U:\Project3\Release\groceryList.txt")
	contents = file.read().split("\n")
	file.close()
	print(Counter(contents))

#Finds and counts a specific item
def findItem(item):
	item = item.lower()
	file = open("U:\Project3\Release\groceryList.txt")
	wordCount = file.read().lower().count(item)
	file.close()
	print("The amount of " + item + "'s is: ")
	return wordCount

#Finds and writes the item frequencies to a new file
def writeFrequency():
	file = open("U:\Project3\Release\groceryList.txt", 'r')
	fileWrite = open("frequency.dat", 'w')
	contents = Counter(file.read().split("\n"))
	for key, value in contents.items():
		fileWrite.write(key + " " + str(value) + "\n")
	file.close()
	fileWrite.close()